﻿using System;

namespace CM_Callouts.PendingCallouts
{
	// Token: 0x02000018 RID: 24
	public enum CalloutCategory
	{
		// Token: 0x04000047 RID: 71
		Undefined,
		// Token: 0x04000048 RID: 72
		Combat,
		// Token: 0x04000049 RID: 73
		Animal
	}
}
