﻿using System;

namespace CM_Callouts
{
	// Token: 0x02000005 RID: 5
	public enum ShowWoundLevel
	{
		// Token: 0x0400001F RID: 31
		None,
		// Token: 0x04000020 RID: 32
		Destroyed,
		// Token: 0x04000021 RID: 33
		Major,
		// Token: 0x04000022 RID: 34
		Serious,
		// Token: 0x04000023 RID: 35
		All
	}
}
