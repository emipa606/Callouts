# CM_Callouts

Original mod for 1.2/1.3 by Captain Muscles here https://github.com/CaptainMuscles/CM_Callouts.


A mod for Rimworld that adds callouts in text form whenever humanlike pawn triggers certain events.

See the wiki page for info on how to add callouts to your own mod!
